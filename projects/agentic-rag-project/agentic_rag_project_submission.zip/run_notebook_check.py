from pathlib import Path
import json
import builtins
import sys

# Make console output robust on Windows terminals that default to cp1252.
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

nb_path = Path(r'C:\Users\Ben\Downloads\agentic_rag_project\agentic_rag_notebook.ipynb')
nb = json.loads(nb_path.read_text(encoding='utf-8'))

ns = {}
original_input = builtins.input


def non_interactive_input(prompt=''):
    print(prompt, end='')
    return ''


builtins.input = non_interactive_input
try:
    for i, cell in enumerate(nb['cells']):
        if cell.get('cell_type') != 'code':
            continue
        src = ''.join(cell.get('source', []))
        if not src.strip():
            continue
        print(f'--- running cell {i+1} ---')
        try:
            exec(compile(src, f'{nb_path.name}#cell{i+1}', 'exec'), ns)
            print('ok')
        except Exception as e:
            print('ERROR', repr(e))
            break
finally:
    builtins.input = original_input
